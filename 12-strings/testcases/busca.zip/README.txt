Arquivo zip gerado em: 28/06/2024 15:17:19 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: String 1