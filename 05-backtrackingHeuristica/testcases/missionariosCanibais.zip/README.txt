Arquivo zip gerado em: 14/04/2024 19:24:39 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: backtrack4_heuristica