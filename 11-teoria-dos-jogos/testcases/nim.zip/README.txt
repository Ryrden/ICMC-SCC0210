Arquivo zip gerado em: 15/06/2024 10:52:23 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Jogos 1