Arquivo zip gerado em: 20/03/2024 19:26:36 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: guloso3 (bonus)